//
//  ViewController.swift
//  How to use global alert functions in swift 4 xcode 9
//
//  Created by Abhishek Verma on 14/07/18.
//  Copyright © 2018 Abhishek Verma. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func ShowAlert(_ sender: Any) {
       // SimpleAlert(title: "Welcome Swifthub", message: "IOS Tutorials")
        simplealertwithaction(title: "Welcome Swifthub", message: "IOS Tutorials") { (true) in
            print("OK Btn Click Successfully")
        }
    }
    
}

