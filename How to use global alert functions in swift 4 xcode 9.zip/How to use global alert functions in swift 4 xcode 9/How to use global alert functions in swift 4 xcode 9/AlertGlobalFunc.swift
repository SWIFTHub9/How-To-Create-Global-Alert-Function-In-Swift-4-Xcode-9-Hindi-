//
//  AlertGlobalFunc.swift
//  How to use global alert functions in swift 4 xcode 9
//
//  Created by Abhishek Verma on 14/07/18.
//  Copyright © 2018 Abhishek Verma. All rights reserved.
//

import Foundation
import AVKit

extension UIViewController
{
    func SimpleAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okbtn = UIAlertAction(title: "ok", style: .default, handler: nil)
        alert.addAction(okbtn)
        self.present(alert, animated: true, completion: nil)
    }
    func simplealertwithaction(title: String, message: String, responseBlock: @escaping (_ isOk: Bool) -> Void)
    {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okbtn = UIAlertAction(title: "Ok", style: .default) { (action:UIAlertAction) in
            responseBlock(true)
            alert.dismiss(animated: true, completion: nil)
        }
        alert.addAction(okbtn)
        self.present(alert, animated: true, completion: nil)
    }
}
